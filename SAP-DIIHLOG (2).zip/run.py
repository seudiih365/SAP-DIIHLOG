"""
SAP DIIHLOG - Ponto de entrada da aplicação.

Execute este arquivo para iniciar o sistema:
    python run.py

Consulte INSTALL.md para instruções completas de instalação.
"""
import sys

from PySide6.QtWidgets import QApplication

from sap_diihlog.app_theme import DARK_THEME_QSS
from sap_diihlog.database import inicializar_banco
from sap_diihlog.main_window import MainWindow


def main() -> int:
    inicializar_banco()

    app = QApplication(sys.argv)
    app.setApplicationName("SAP DIIHLOG")
    app.setStyleSheet(DARK_THEME_QSS)

    janela = MainWindow()
    janela.show()

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
