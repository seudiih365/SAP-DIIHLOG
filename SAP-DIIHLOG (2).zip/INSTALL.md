# Instalação do SAP DIIHLOG

Este guia explica **como instalar e colocar o sistema para rodar** na sua
máquina. Ele não explica como usar as telas — isso fica para outro momento.

Sistema testado em Windows 10/11, Linux (Ubuntu/Debian) e macOS.

---

## 1. Pré-requisitos

Você precisa apenas de duas coisas instaladas: **Python** e o **Git** (o Git
só é necessário se for clonar o repositório; se for baixar o `.zip`, pode
pular essa parte).

### 1.1 Instalar o Python

O SAP DIIHLOG exige **Python 3.10 ou superior**.

**Windows:**
1. Acesse https://www.python.org/downloads/
2. Baixe a versão mais recente do Python 3.x
3. Ao rodar o instalador, **marque a caixa "Add python.exe to PATH"** antes
   de clicar em "Install Now" — esse é o erro mais comum de instalação
4. Confirme a instalação abrindo o **Prompt de Comando** (`cmd`) e digitando:
   ```
   python --version
   ```
   Deve aparecer algo como `Python 3.12.x`

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip
python3 --version
```

**macOS:**
```bash
brew install python
python3 --version
```
(Se não tiver o Homebrew, instale pelo site oficial do Python, mesmo link
do Windows.)

### 1.2 Instalar o Git (opcional, só se for clonar o repositório)

- Windows: https://git-scm.com/download/win
- Linux: `sudo apt install git`
- macOS: `brew install git`

---

## 2. Obter os arquivos do projeto

**Opção A — clonando o repositório (recomendado):**
```bash
git clone https://github.com/seudiih365/SAP-DIIHLOG.git
cd SAP-DIIHLOG
```

**Opção B — baixando o .zip:**
1. No GitHub, clique em **Code → Download ZIP**
2. Extraia o arquivo em uma pasta de sua preferência
3. Abra o terminal/prompt de comando **dentro dessa pasta**

---

## 3. Criar o ambiente virtual

O ambiente virtual mantém as dependências do SAP DIIHLOG isoladas do resto
do seu sistema, evitando conflitos com outros programas Python.

**Windows (Prompt de Comando ou PowerShell):**
```
python -m venv .venv
.venv\Scripts\activate
```

**Linux / macOS:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

Se funcionou, o nome `(.venv)` deve aparecer no início da linha do seu
terminal. **Esse ambiente precisa estar ativo toda vez que for rodar o
sistema** (repita apenas o comando de `activate` nas próximas vezes — não
precisa criar o `.venv` de novo).

---

## 4. Instalar as dependências

Com o ambiente virtual ativo:
```bash
pip install -r requirements.txt
```

Isso instala o **PySide6** (a biblioteca de interface gráfica). O download
pode demorar alguns minutos na primeira vez, pois o pacote é grande
(~100–150 MB).

---

## 5. Rodar o sistema

Ainda com o `.venv` ativo, na pasta raiz do projeto:

**Windows:**
```
python run.py
```

**Linux / macOS:**
```bash
python3 run.py
```

Se tudo estiver certo, a janela do SAP DIIHLOG deve abrir. Na primeira
execução, o sistema cria automaticamente um arquivo `diihlog.db` na pasta
do projeto — é o seu banco de dados local, já com a ORBELOG e a ROTA FORTE
pré-cadastradas. Esse arquivo **não é enviado ao GitHub** (está no
`.gitignore`), então cada instalação começa com seus próprios dados.

---

## 6. Problemas comuns

| Sintoma | Causa provável | Solução |
|---|---|---|
| `'python' não é reconhecido...` (Windows) | Python não foi adicionado ao PATH | Reinstale o Python marcando "Add to PATH", ou use `py` no lugar de `python` |
| `ModuleNotFoundError: No module named 'PySide6'` | Ambiente virtual não está ativo, ou dependências não foram instaladas | Rode `activate` de novo e depois `pip install -r requirements.txt` |
| Janela não abre e aparece erro sobre `xcb` (Linux) | Faltam bibliotecas gráficas do sistema | `sudo apt install libxcb-cursor0 libxkbcommon-x11-0` |
| `pip` muito lento ou trava | Rede instável | Tente novamente ou use `pip install -r requirements.txt --timeout 120` |
| Quero recomeçar do zero (apagar todos os dados) | — | Feche o sistema e apague o arquivo `diihlog.db`; ele é recriado vazio na próxima abertura |

---

## 7. Próxima vez que for abrir o sistema

Você não precisa repetir tudo — só os passos 3 (ativar o `.venv`) e 5
(rodar `python run.py`), dentro da pasta do projeto.

**Windows:**
```
.venv\Scripts\activate
python run.py
```

**Linux / macOS:**
```bash
source .venv/bin/activate
python3 run.py
```
