"""SAP DIIHLOG - Sistema de gestão para operações de logística (universo ETS2)."""

__version__ = "0.1.0"
