"""Página de cadastro das empresas/filiais do grupo."""
from PySide6.QtWidgets import (
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.database import conexao


class PaginaEmpresas(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        layout.addWidget(self._montar_formulario())

        self.tabela = QTableWidget(0, 2)
        self.tabela.setHorizontalHeaderLabels(["Empresa", "Sede"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabela.setAlternatingRowColors(True)
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.tabela, stretch=1)

        self.atualizar()

    def _montar_formulario(self) -> QFrame:
        cartao = QFrame()
        cartao.setProperty("class", "Cartao")
        layout = QVBoxLayout(cartao)

        formulario = QFormLayout()
        formulario.setSpacing(10)

        self.campo_nome = QLineEdit()
        self.campo_sede = QLineEdit()

        formulario.addRow("Nome da empresa", self.campo_nome)
        formulario.addRow("Sede", self.campo_sede)

        layout.addLayout(formulario)

        linha_botoes = QHBoxLayout()
        linha_botoes.addStretch(1)
        botao_salvar = QPushButton("Adicionar empresa")
        botao_salvar.clicked.connect(self._salvar_empresa)
        linha_botoes.addWidget(botao_salvar)
        layout.addLayout(linha_botoes)

        return cartao

    def _salvar_empresa(self) -> None:
        nome = self.campo_nome.text().strip()
        if not nome:
            return

        with conexao() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO empresas (nome, sede) VALUES (?, ?)",
                (nome, self.campo_sede.text().strip()),
            )

        self.campo_nome.clear()
        self.campo_sede.clear()

        self.atualizar()

    def atualizar(self) -> None:
        with conexao() as conn:
            linhas = conn.execute(
                "SELECT nome, sede FROM empresas WHERE ativo = 1 ORDER BY nome"
            ).fetchall()

        self.tabela.setRowCount(len(linhas))
        for linha_idx, linha in enumerate(linhas):
            self.tabela.setItem(linha_idx, 0, QTableWidgetItem(linha["nome"]))
            self.tabela.setItem(linha_idx, 1, QTableWidgetItem(linha["sede"] or "—"))
