"""Página de cadastro e listagem de veículos da frota."""
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.database import conexao

STATUS_OPCOES = ["Disponível", "Em viagem", "Manutenção", "Inativo"]


class PaginaFrota(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        layout.addWidget(self._montar_formulario())

        self.tabela = QTableWidget(0, 5)
        self.tabela.setHorizontalHeaderLabels(
            ["Identificação", "Modelo", "Empresa", "Status", "Hodômetro (km)"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabela.setAlternatingRowColors(True)
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.tabela, stretch=1)

        self.atualizar()

    def _montar_formulario(self) -> QFrame:
        cartao = QFrame()
        cartao.setProperty("class", "Cartao")
        layout = QVBoxLayout(cartao)

        formulario = QFormLayout()
        formulario.setSpacing(10)

        self.campo_identificacao = QLineEdit()
        self.campo_modelo = QLineEdit()
        self.campo_empresa = QComboBox()
        self.campo_status = QComboBox()
        self.campo_status.addItems(STATUS_OPCOES)
        self.campo_hodometro = QDoubleSpinBox()
        self.campo_hodometro.setRange(0, 5_000_000)
        self.campo_hodometro.setSuffix(" km")

        formulario.addRow("Identificação", self.campo_identificacao)
        formulario.addRow("Modelo", self.campo_modelo)
        formulario.addRow("Empresa", self.campo_empresa)
        formulario.addRow("Status", self.campo_status)
        formulario.addRow("Hodômetro", self.campo_hodometro)

        layout.addLayout(formulario)

        linha_botoes = QHBoxLayout()
        linha_botoes.addStretch(1)
        botao_salvar = QPushButton("Cadastrar veículo")
        botao_salvar.clicked.connect(self._salvar_veiculo)
        linha_botoes.addWidget(botao_salvar)
        layout.addLayout(linha_botoes)

        return cartao

    def _carregar_empresas(self) -> None:
        self.campo_empresa.clear()
        with conexao() as conn:
            for linha in conn.execute("SELECT id, nome FROM empresas WHERE ativo = 1"):
                self.campo_empresa.addItem(linha["nome"], userData=linha["id"])

    def _salvar_veiculo(self) -> None:
        if not self.campo_identificacao.text().strip():
            return

        with conexao() as conn:
            conn.execute(
                """
                INSERT INTO veiculos (placa_ficticia, modelo, empresa_id, status, hodometro_km)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    self.campo_identificacao.text().strip(),
                    self.campo_modelo.text().strip(),
                    self.campo_empresa.currentData(),
                    self.campo_status.currentText(),
                    self.campo_hodometro.value(),
                ),
            )

        self.campo_identificacao.clear()
        self.campo_modelo.clear()
        self.campo_hodometro.setValue(0)

        self.atualizar()

    def atualizar(self) -> None:
        self._carregar_empresas()

        with conexao() as conn:
            linhas = conn.execute(
                """
                SELECT v.placa_ficticia, v.modelo, e.nome AS empresa,
                       v.status, v.hodometro_km
                FROM veiculos v
                JOIN empresas e ON e.id = v.empresa_id
                ORDER BY v.id DESC
                """
            ).fetchall()

        self.tabela.setRowCount(len(linhas))
        for linha_idx, linha in enumerate(linhas):
            valores = [
                linha["placa_ficticia"],
                linha["modelo"] or "—",
                linha["empresa"],
                linha["status"],
                f"{linha['hodometro_km']:.0f}",
            ]
            for coluna_idx, valor in enumerate(valores):
                self.tabela.setItem(linha_idx, coluna_idx, QTableWidgetItem(valor))
