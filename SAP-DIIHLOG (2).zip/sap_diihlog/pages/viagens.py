"""Página de registro e listagem de viagens (fretes)."""
from datetime import date

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.database import conexao


class PaginaViagens(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        layout.addWidget(self._montar_formulario())

        self.tabela = QTableWidget(0, 7)
        self.tabela.setHorizontalHeaderLabels(
            ["Data", "Empresa", "Origem", "Destino", "Distância (km)", "Receita (€)", "Custo (€)"]
        )
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabela.setAlternatingRowColors(True)
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.tabela, stretch=1)

        self.atualizar()

    def _montar_formulario(self) -> QFrame:
        cartao = QFrame()
        cartao.setProperty("class", "Cartao")
        layout = QVBoxLayout(cartao)

        formulario = QFormLayout()
        formulario.setSpacing(10)

        self.campo_empresa = QComboBox()
        self.campo_origem = QLineEdit()
        self.campo_destino = QLineEdit()
        self.campo_carga = QLineEdit()
        self.campo_distancia = QDoubleSpinBox()
        self.campo_distancia.setRange(0, 20000)
        self.campo_distancia.setSuffix(" km")
        self.campo_receita = QDoubleSpinBox()
        self.campo_receita.setRange(0, 1_000_000)
        self.campo_receita.setPrefix("€ ")
        self.campo_custo = QDoubleSpinBox()
        self.campo_custo.setRange(0, 1_000_000)
        self.campo_custo.setPrefix("€ ")
        self.campo_data = QDateEdit()
        self.campo_data.setDate(date.today())
        self.campo_data.setCalendarPopup(True)

        formulario.addRow("Empresa", self.campo_empresa)
        formulario.addRow("Origem", self.campo_origem)
        formulario.addRow("Destino", self.campo_destino)
        formulario.addRow("Carga", self.campo_carga)
        formulario.addRow("Distância", self.campo_distancia)
        formulario.addRow("Receita", self.campo_receita)
        formulario.addRow("Custo", self.campo_custo)
        formulario.addRow("Data", self.campo_data)

        layout.addLayout(formulario)

        linha_botoes = QHBoxLayout()
        linha_botoes.addStretch(1)
        botao_salvar = QPushButton("Registrar viagem")
        botao_salvar.clicked.connect(self._salvar_viagem)
        linha_botoes.addWidget(botao_salvar)
        layout.addLayout(linha_botoes)

        return cartao

    def _carregar_empresas(self) -> None:
        self.campo_empresa.clear()
        with conexao() as conn:
            for linha in conn.execute("SELECT id, nome FROM empresas WHERE ativo = 1"):
                self.campo_empresa.addItem(linha["nome"], userData=linha["id"])

    def _salvar_viagem(self) -> None:
        if not self.campo_origem.text().strip() or not self.campo_destino.text().strip():
            return

        with conexao() as conn:
            conn.execute(
                """
                INSERT INTO viagens
                    (empresa_id, origem, destino, carga, distancia_km, receita, custo, data)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    self.campo_empresa.currentData(),
                    self.campo_origem.text().strip(),
                    self.campo_destino.text().strip(),
                    self.campo_carga.text().strip(),
                    self.campo_distancia.value(),
                    self.campo_receita.value(),
                    self.campo_custo.value(),
                    self.campo_data.date().toString("yyyy-MM-dd"),
                ),
            )

        self.campo_origem.clear()
        self.campo_destino.clear()
        self.campo_carga.clear()
        self.campo_distancia.setValue(0)
        self.campo_receita.setValue(0)
        self.campo_custo.setValue(0)

        self.atualizar()

    def atualizar(self) -> None:
        self._carregar_empresas()

        with conexao() as conn:
            linhas = conn.execute(
                """
                SELECT v.data, e.nome AS empresa, v.origem, v.destino,
                       v.distancia_km, v.receita, v.custo
                FROM viagens v
                JOIN empresas e ON e.id = v.empresa_id
                ORDER BY v.data DESC, v.id DESC
                """
            ).fetchall()

        self.tabela.setRowCount(len(linhas))
        for linha_idx, linha in enumerate(linhas):
            valores = [
                linha["data"],
                linha["empresa"],
                linha["origem"],
                linha["destino"],
                f"{linha['distancia_km']:.0f}",
                f"{linha['receita']:.2f}",
                f"{linha['custo']:.2f}",
            ]
            for coluna_idx, valor in enumerate(valores):
                self.tabela.setItem(linha_idx, coluna_idx, QTableWidgetItem(valor))
