"""Página de relatórios: gráfico receita x custo por mês e exportação em CSV."""
import csv
from collections import defaultdict

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.app_theme import COR_FUNDO_PAINEL, COR_NEGATIVO, COR_POSITIVO, COR_TEXTO
from sap_diihlog.database import conexao


class PaginaRelatorios(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        cartao_grafico = QFrame()
        cartao_grafico.setProperty("class", "Cartao")
        layout_grafico = QVBoxLayout(cartao_grafico)

        titulo = QLabel("Receita x Custo por mês")
        titulo.setStyleSheet("font-weight: 600; font-size: 14px;")
        layout_grafico.addWidget(titulo)

        self.figura = Figure(figsize=(6, 3.2), facecolor=COR_FUNDO_PAINEL)
        self.canvas = FigureCanvasQTAgg(self.figura)
        layout_grafico.addWidget(self.canvas)

        layout.addWidget(cartao_grafico)

        linha_botoes = QHBoxLayout()
        linha_botoes.addStretch(1)
        botao_exportar = QPushButton("Exportar extrato (.csv)")
        botao_exportar.clicked.connect(self._exportar_csv)
        linha_botoes.addWidget(botao_exportar)
        layout.addLayout(linha_botoes)

        layout.addStretch(1)

        self.atualizar()

    def _buscar_dados_mensais(self) -> dict:
        """Retorna {mes: {'receita': x, 'custo': y}} ordenado cronologicamente."""
        dados = defaultdict(lambda: {"receita": 0.0, "custo": 0.0})

        with conexao() as conn:
            for linha in conn.execute(
                "SELECT substr(data, 1, 7) AS mes, receita, custo FROM viagens"
            ):
                dados[linha["mes"]]["receita"] += linha["receita"] or 0
                dados[linha["mes"]]["custo"] += linha["custo"] or 0

            for linha in conn.execute(
                "SELECT substr(data, 1, 7) AS mes, tipo, valor FROM lancamentos_financeiros"
            ):
                chave = "receita" if linha["tipo"] == "Receita" else "custo"
                dados[linha["mes"]][chave] += linha["valor"] or 0

        return dict(sorted(dados.items()))

    def _redesenhar_grafico(self) -> None:
        dados = self._buscar_dados_mensais()

        self.figura.clear()
        eixo = self.figura.add_subplot(111)
        eixo.set_facecolor(COR_FUNDO_PAINEL)
        self.figura.patch.set_facecolor(COR_FUNDO_PAINEL)

        if not dados:
            eixo.text(
                0.5, 0.5, "Sem dados suficientes ainda",
                ha="center", va="center", color=COR_TEXTO, transform=eixo.transAxes,
            )
        else:
            meses = list(dados.keys())
            receitas = [dados[m]["receita"] for m in meses]
            custos = [dados[m]["custo"] for m in meses]

            posicoes = range(len(meses))
            largura = 0.35

            eixo.bar(
                [p - largura / 2 for p in posicoes], receitas, largura,
                label="Receita", color=COR_POSITIVO,
            )
            eixo.bar(
                [p + largura / 2 for p in posicoes], custos, largura,
                label="Custo", color=COR_NEGATIVO,
            )
            eixo.set_xticks(list(posicoes))
            eixo.set_xticklabels(meses, color=COR_TEXTO)
            eixo.legend(facecolor=COR_FUNDO_PAINEL, labelcolor=COR_TEXTO, frameon=False)

        eixo.tick_params(colors=COR_TEXTO)
        for spine in eixo.spines.values():
            spine.set_color(COR_TEXTO)
        self.figura.tight_layout()
        self.canvas.draw()

    def _exportar_csv(self) -> None:
        caminho, _ = QFileDialog.getSaveFileName(
            self, "Exportar extrato", "extrato_diihlog.csv", "CSV (*.csv)"
        )
        if not caminho:
            return

        with conexao() as conn:
            viagens = conn.execute(
                """
                SELECT v.data, e.nome AS empresa, 'Viagem' AS origem_registro,
                       (v.origem || ' → ' || v.destino) AS descricao,
                       v.receita, v.custo
                FROM viagens v JOIN empresas e ON e.id = v.empresa_id
                """
            ).fetchall()
            lancamentos = conn.execute(
                """
                SELECT l.data, e.nome AS empresa, 'Lançamento' AS origem_registro,
                       l.descricao,
                       CASE WHEN l.tipo = 'Receita' THEN l.valor ELSE 0 END AS receita,
                       CASE WHEN l.tipo = 'Despesa' THEN l.valor ELSE 0 END AS custo
                FROM lancamentos_financeiros l JOIN empresas e ON e.id = l.empresa_id
                """
            ).fetchall()

        linhas = sorted([*viagens, *lancamentos], key=lambda linha: linha["data"])

        try:
            with open(caminho, "w", newline="", encoding="utf-8-sig") as arquivo:
                escritor = csv.writer(arquivo, delimiter=";")
                escritor.writerow(["Data", "Empresa", "Origem", "Descrição", "Receita (€)", "Custo (€)"])
                for linha in linhas:
                    escritor.writerow([
                        linha["data"], linha["empresa"], linha["origem_registro"],
                        linha["descricao"], f"{linha['receita']:.2f}", f"{linha['custo']:.2f}",
                    ])
        except OSError as erro:
            QMessageBox.critical(self, "Erro ao exportar", str(erro))
            return

        QMessageBox.information(self, "Exportado", f"Extrato salvo em:\n{caminho}")

    def atualizar(self) -> None:
        self._redesenhar_grafico()
