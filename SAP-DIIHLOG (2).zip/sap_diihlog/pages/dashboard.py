"""Página inicial: indicadores consolidados do grupo."""
from PySide6.QtWidgets import QFrame, QGridLayout, QLabel, QVBoxLayout, QWidget

from sap_diihlog.database import conexao


class CartaoKpi(QFrame):
    def __init__(self, rotulo: str):
        super().__init__()
        self.setProperty("class", "Cartao")
        self.setFrameShape(QFrame.Shape.NoFrame)
        layout = QVBoxLayout(self)

        self.valor = QLabel("—")
        self.valor.setProperty("class", "KpiValor")
        layout.addWidget(self.valor)

        rotulo_widget = QLabel(rotulo)
        rotulo_widget.setProperty("class", "KpiRotulo")
        layout.addWidget(rotulo_widget)

    def definir_valor(self, texto: str) -> None:
        self.valor.setText(texto)


class PaginaDashboard(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)

        grade = QGridLayout()
        grade.setSpacing(16)
        layout.addLayout(grade)
        layout.addStretch(1)

        self.kpi_viagens = CartaoKpi("Viagens registradas")
        self.kpi_receita = CartaoKpi("Receita total (€)")
        self.kpi_custo = CartaoKpi("Custo total (€)")
        self.kpi_saldo = CartaoKpi("Saldo (€)")

        grade.addWidget(self.kpi_viagens, 0, 0)
        grade.addWidget(self.kpi_receita, 0, 1)
        grade.addWidget(self.kpi_custo, 0, 2)
        grade.addWidget(self.kpi_saldo, 0, 3)

        self.atualizar()

    def atualizar(self) -> None:
        with conexao() as conn:
            total_viagens = conn.execute(
                "SELECT COUNT(*) AS c FROM viagens"
            ).fetchone()["c"]
            receita_viagens = conn.execute(
                "SELECT COALESCE(SUM(receita), 0) AS s FROM viagens"
            ).fetchone()["s"]
            custo_viagens = conn.execute(
                "SELECT COALESCE(SUM(custo), 0) AS s FROM viagens"
            ).fetchone()["s"]
            receita_lanc = conn.execute(
                "SELECT COALESCE(SUM(valor), 0) AS s FROM lancamentos_financeiros "
                "WHERE tipo = 'Receita'"
            ).fetchone()["s"]
            despesa_lanc = conn.execute(
                "SELECT COALESCE(SUM(valor), 0) AS s FROM lancamentos_financeiros "
                "WHERE tipo = 'Despesa'"
            ).fetchone()["s"]

        receita_total = receita_viagens + receita_lanc
        custo_total = custo_viagens + despesa_lanc
        saldo = receita_total - custo_total

        self.kpi_viagens.definir_valor(str(total_viagens))
        self.kpi_receita.definir_valor(f"€ {receita_total:,.2f}")
        self.kpi_custo.definir_valor(f"€ {custo_total:,.2f}")
        self.kpi_saldo.definir_valor(f"€ {saldo:,.2f}")
