"""Página de lançamentos financeiros (receitas e despesas avulsas)."""
from datetime import date

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLineEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.database import conexao


class PaginaFinanceiro(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(16)

        layout.addWidget(self._montar_formulario())

        self.tabela = QTableWidget(0, 4)
        self.tabela.setHorizontalHeaderLabels(["Data", "Empresa", "Descrição", "Valor (€)"])
        self.tabela.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tabela.setAlternatingRowColors(True)
        self.tabela.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.tabela, stretch=1)

        self.atualizar()

    def _montar_formulario(self) -> QFrame:
        cartao = QFrame()
        cartao.setProperty("class", "Cartao")
        layout = QVBoxLayout(cartao)

        formulario = QFormLayout()
        formulario.setSpacing(10)

        self.campo_empresa = QComboBox()
        self.campo_descricao = QLineEdit()
        self.campo_tipo = QComboBox()
        self.campo_tipo.addItems(["Receita", "Despesa"])
        self.campo_valor = QDoubleSpinBox()
        self.campo_valor.setRange(0, 1_000_000)
        self.campo_valor.setPrefix("€ ")
        self.campo_data = QDateEdit()
        self.campo_data.setDate(date.today())
        self.campo_data.setCalendarPopup(True)

        formulario.addRow("Empresa", self.campo_empresa)
        formulario.addRow("Descrição", self.campo_descricao)
        formulario.addRow("Tipo", self.campo_tipo)
        formulario.addRow("Valor", self.campo_valor)
        formulario.addRow("Data", self.campo_data)

        layout.addLayout(formulario)

        linha_botoes = QHBoxLayout()
        linha_botoes.addStretch(1)
        botao_salvar = QPushButton("Lançar")
        botao_salvar.clicked.connect(self._salvar_lancamento)
        linha_botoes.addWidget(botao_salvar)
        layout.addLayout(linha_botoes)

        return cartao

    def _carregar_empresas(self) -> None:
        self.campo_empresa.clear()
        with conexao() as conn:
            for linha in conn.execute("SELECT id, nome FROM empresas WHERE ativo = 1"):
                self.campo_empresa.addItem(linha["nome"], userData=linha["id"])

    def _salvar_lancamento(self) -> None:
        if not self.campo_descricao.text().strip():
            return

        with conexao() as conn:
            conn.execute(
                """
                INSERT INTO lancamentos_financeiros (empresa_id, descricao, tipo, valor, data)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    self.campo_empresa.currentData(),
                    self.campo_descricao.text().strip(),
                    self.campo_tipo.currentText(),
                    self.campo_valor.value(),
                    self.campo_data.date().toString("yyyy-MM-dd"),
                ),
            )

        self.campo_descricao.clear()
        self.campo_valor.setValue(0)

        self.atualizar()

    def atualizar(self) -> None:
        self._carregar_empresas()

        with conexao() as conn:
            linhas = conn.execute(
                """
                SELECT l.data, e.nome AS empresa, l.descricao, l.tipo, l.valor
                FROM lancamentos_financeiros l
                JOIN empresas e ON e.id = l.empresa_id
                ORDER BY l.data DESC, l.id DESC
                """
            ).fetchall()

        self.tabela.setRowCount(len(linhas))
        for linha_idx, linha in enumerate(linhas):
            sinal = "+" if linha["tipo"] == "Receita" else "-"
            valores = [
                linha["data"],
                linha["empresa"],
                linha["descricao"],
                f"{sinal} {linha['valor']:.2f}",
            ]
            for coluna_idx, valor in enumerate(valores):
                self.tabela.setItem(linha_idx, coluna_idx, QTableWidgetItem(valor))
