"""
Camada de acesso ao banco de dados do SAP DIIHLOG.

Usa SQLite (biblioteca padrão do Python, sem dependências externas) para
manter a instalação simples. O arquivo do banco é criado automaticamente
na raiz do projeto na primeira execução.
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path

CAMINHO_BANCO = Path(__file__).resolve().parent.parent / "diihlog.db"


@contextmanager
def conexao():
    """Fornece uma conexão SQLite com foreign keys habilitadas."""
    conn = sqlite3.connect(CAMINHO_BANCO)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS empresas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL UNIQUE,
    sede TEXT,
    ativo INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS veiculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placa_ficticia TEXT NOT NULL,
    modelo TEXT,
    empresa_id INTEGER NOT NULL REFERENCES empresas(id),
    status TEXT NOT NULL DEFAULT 'Disponível',
    hodometro_km REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS viagens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    empresa_id INTEGER NOT NULL REFERENCES empresas(id),
    veiculo_id INTEGER REFERENCES veiculos(id),
    origem TEXT NOT NULL,
    destino TEXT NOT NULL,
    carga TEXT,
    distancia_km REAL NOT NULL DEFAULT 0,
    receita REAL NOT NULL DEFAULT 0,
    custo REAL NOT NULL DEFAULT 0,
    data TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Concluída'
);

CREATE TABLE IF NOT EXISTS lancamentos_financeiros (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    empresa_id INTEGER NOT NULL REFERENCES empresas(id),
    descricao TEXT NOT NULL,
    tipo TEXT NOT NULL CHECK (tipo IN ('Receita', 'Despesa')),
    valor REAL NOT NULL,
    data TEXT NOT NULL
);
"""

EMPRESAS_SEED = [
    ("ORBELOG Global Logistics", "Rotterdam"),
    ("ROTA FORTE Logística", "Milão"),
]


def inicializar_banco() -> None:
    """Cria as tabelas (se não existirem) e semeia as empresas padrão."""
    with conexao() as conn:
        conn.executescript(SCHEMA)

        cur = conn.execute("SELECT COUNT(*) AS total FROM empresas")
        if cur.fetchone()["total"] == 0:
            conn.executemany(
                "INSERT INTO empresas (nome, sede) VALUES (?, ?)",
                EMPRESAS_SEED,
            )
