"""
Tema visual do SAP DIIHLOG.

Paleta inspirada em softwares corporativos europeus (tons de grafite e azul
petróleo, cantos retos, tipografia condensada) — evitando o visual "gamer"
e priorizando a leitura de dados densos, como em um SAP GUI real.
"""

COR_FUNDO = "#1c2126"
COR_FUNDO_PAINEL = "#242a31"
COR_FUNDO_INPUT = "#2c333b"
COR_BORDA = "#39424c"
COR_TEXTO = "#e6e9ec"
COR_TEXTO_SECUNDARIO = "#9aa5b1"
COR_DESTAQUE = "#3d7ea6"
COR_DESTAQUE_HOVER = "#4d94c2"
COR_POSITIVO = "#4caf78"
COR_NEGATIVO = "#c0554b"

__all__ = [
    "DARK_THEME_QSS",
    "COR_FUNDO",
    "COR_FUNDO_PAINEL",
    "COR_FUNDO_INPUT",
    "COR_BORDA",
    "COR_TEXTO",
    "COR_TEXTO_SECUNDARIO",
    "COR_DESTAQUE",
    "COR_DESTAQUE_HOVER",
    "COR_POSITIVO",
    "COR_NEGATIVO",
]

DARK_THEME_QSS = f"""
* {{
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 13px;
    color: {COR_TEXTO};
}}

QMainWindow, QWidget {{
    background-color: {COR_FUNDO};
}}

#Sidebar {{
    background-color: {COR_FUNDO_PAINEL};
    border-right: 1px solid {COR_BORDA};
}}

#SidebarTitulo {{
    font-size: 15px;
    font-weight: 600;
    padding: 18px 14px 4px 14px;
    letter-spacing: 1px;
}}

#SidebarSubtitulo {{
    color: {COR_TEXTO_SECUNDARIO};
    padding: 0px 14px 16px 14px;
    font-size: 11px;
}}

QListWidget#MenuLateral {{
    background-color: transparent;
    border: none;
    outline: 0;
    padding: 4px;
}}

QListWidget#MenuLateral::item {{
    padding: 10px 14px;
    border-radius: 4px;
    margin: 2px 6px;
}}

QListWidget#MenuLateral::item:selected {{
    background-color: {COR_DESTAQUE};
    color: white;
}}

QListWidget#MenuLateral::item:hover:!selected {{
    background-color: {COR_FUNDO_INPUT};
}}

#Cabecalho {{
    background-color: {COR_FUNDO_PAINEL};
    border-bottom: 1px solid {COR_BORDA};
}}

#TituloPagina {{
    font-size: 17px;
    font-weight: 600;
    padding: 14px 20px;
}}

QFrame.Cartao {{
    background-color: {COR_FUNDO_PAINEL};
    border: 1px solid {COR_BORDA};
    border-radius: 6px;
}}

QLabel.KpiValor {{
    font-size: 22px;
    font-weight: 700;
}}

QLabel.KpiRotulo {{
    color: {COR_TEXTO_SECUNDARIO};
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
}}

QTableWidget {{
    background-color: {COR_FUNDO_PAINEL};
    alternate-background-color: {COR_FUNDO_INPUT};
    gridline-color: {COR_BORDA};
    border: 1px solid {COR_BORDA};
    border-radius: 4px;
}}

QHeaderView::section {{
    background-color: {COR_FUNDO_INPUT};
    color: {COR_TEXTO_SECUNDARIO};
    padding: 8px;
    border: none;
    border-bottom: 1px solid {COR_BORDA};
    font-weight: 600;
    text-transform: uppercase;
    font-size: 11px;
}}

QPushButton {{
    background-color: {COR_DESTAQUE};
    color: white;
    border: none;
    border-radius: 4px;
    padding: 8px 16px;
    font-weight: 600;
}}

QPushButton:hover {{
    background-color: {COR_DESTAQUE_HOVER};
}}

QPushButton:disabled {{
    background-color: {COR_BORDA};
    color: {COR_TEXTO_SECUNDARIO};
}}

QPushButton.Secundario {{
    background-color: {COR_FUNDO_INPUT};
    border: 1px solid {COR_BORDA};
}}

QLineEdit, QComboBox, QDoubleSpinBox, QDateEdit {{
    background-color: {COR_FUNDO_INPUT};
    border: 1px solid {COR_BORDA};
    border-radius: 4px;
    padding: 6px 8px;
}}

QLineEdit:focus, QComboBox:focus {{
    border: 1px solid {COR_DESTAQUE};
}}
"""
