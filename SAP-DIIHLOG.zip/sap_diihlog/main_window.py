"""Janela principal: menu lateral + área de conteúdo (stacked pages)."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from sap_diihlog.pages.dashboard import PaginaDashboard
from sap_diihlog.pages.empresas import PaginaEmpresas
from sap_diihlog.pages.financeiro import PaginaFinanceiro
from sap_diihlog.pages.frota import PaginaFrota
from sap_diihlog.pages.viagens import PaginaViagens

MODULOS = [
    ("Dashboard", PaginaDashboard),
    ("Viagens", PaginaViagens),
    ("Frota", PaginaFrota),
    ("Financeiro", PaginaFinanceiro),
    ("Empresas", PaginaEmpresas),
]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SAP DIIHLOG")
        self.resize(1200, 760)

        central = QWidget()
        self.setCentralWidget(central)
        layout_raiz = QHBoxLayout(central)
        layout_raiz.setContentsMargins(0, 0, 0, 0)
        layout_raiz.setSpacing(0)

        layout_raiz.addWidget(self._montar_sidebar())

        area_direita = QWidget()
        layout_direita = QVBoxLayout(area_direita)
        layout_direita.setContentsMargins(0, 0, 0, 0)
        layout_direita.setSpacing(0)

        self.cabecalho = self._montar_cabecalho()
        layout_direita.addWidget(self.cabecalho)

        self.stack = QStackedWidget()
        self.paginas = {}
        for nome, classe_pagina in MODULOS:
            pagina = classe_pagina()
            self.paginas[nome] = pagina
            self.stack.addWidget(pagina)
        layout_direita.addWidget(self.stack, stretch=1)

        layout_raiz.addWidget(area_direita, stretch=1)

        self.menu.setCurrentRow(0)

    def _montar_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(220)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        titulo = QLabel("SAP DIIHLOG")
        titulo.setObjectName("SidebarTitulo")
        layout.addWidget(titulo)

        subtitulo = QLabel("Grupo DIHH · Logística")
        subtitulo.setObjectName("SidebarSubtitulo")
        layout.addWidget(subtitulo)

        self.menu = QListWidget()
        self.menu.setObjectName("MenuLateral")
        for nome, _ in MODULOS:
            self.menu.addItem(QListWidgetItem(nome))
        self.menu.currentRowChanged.connect(self._trocar_pagina)
        layout.addWidget(self.menu, stretch=1)

        return sidebar

    def _montar_cabecalho(self) -> QFrame:
        cabecalho = QFrame()
        cabecalho.setObjectName("Cabecalho")
        layout = QHBoxLayout(cabecalho)
        layout.setContentsMargins(0, 0, 0, 0)

        self.titulo_pagina = QLabel(MODULOS[0][0])
        self.titulo_pagina.setObjectName("TituloPagina")
        layout.addWidget(self.titulo_pagina)
        layout.addStretch(1)

        return cabecalho

    def _trocar_pagina(self, indice: int) -> None:
        self.stack.setCurrentIndex(indice)
        nome = MODULOS[indice][0]
        self.titulo_pagina.setText(nome)
        pagina = self.stack.currentWidget()
        if hasattr(pagina, "atualizar"):
            pagina.atualizar()
