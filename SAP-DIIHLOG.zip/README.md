# SAP DIIHLOG

Sistema de gestão corporativa (estilo ERP/SAP) para operações de logística,
desenvolvido em Python com interface desktop nativa. Faz parte do universo
de simulação de negócios construído em torno do Euro Truck Simulator 2,
cobrindo o grupo **DIHH LOG** — ORBELOG Global Logistics e ROTA FORTE
Logística.

> 📦 Quer instalar? Veja o [tutorial de instalação](INSTALL.md).

## Visão geral

- **Interface:** aplicativo desktop nativo (PySide6/Qt), sem navegador,
  com visual sóbrio inspirado em softwares corporativos europeus
- **Dados:** banco SQLite local, criado automaticamente na primeira execução
- **Idioma:** interface e código de domínio em português

## Módulos atuais

| Módulo | Função |
|---|---|
| Dashboard | Indicadores consolidados (viagens, receita, custo, saldo) |
| Viagens | Registro de fretes: origem, destino, distância, receita e custo |
| Frota | Cadastro de veículos e status operacional |
| Financeiro | Lançamentos avulsos de receita e despesa |
| Empresas | Cadastro das empresas/filiais do grupo |

## Stack técnica

- Python 3.10+
- [PySide6](https://doc.qt.io/qtforpython/) — binding oficial do Qt (interface gráfica)
- SQLite (biblioteca padrão do Python) — persistência local

## Estrutura do projeto

```
SAP-DIIHLOG/
├── run.py                      # ponto de entrada
├── requirements.txt
├── INSTALL.md                  # tutorial de instalação
├── sap_diihlog/
│   ├── app_theme.py             # tema visual (QSS)
│   ├── database.py              # schema e conexão SQLite
│   ├── main_window.py           # janela principal / navegação
│   └── pages/
│       ├── dashboard.py
│       ├── viagens.py
│       ├── frota.py
│       ├── financeiro.py
│       └── empresas.py
```

## Roteiro (próximos módulos)

- [ ] Relatórios financeiros por período e por empresa
- [ ] Gráficos de desempenho (receita x custo ao longo do tempo)
- [ ] Exportação de dados (CSV/PDF)
- [ ] Cadastro de motoristas/operadores
- [ ] Controle de manutenção de frota com alertas por km rodado

## Licença

Projeto pessoal / uso não comercial.
